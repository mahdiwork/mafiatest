import os
LogFile = 'mafia.log'
Local = True
#config={'user': os.environ['database_user'], 'password': os.environ['database_password'], 'host': 'localhost','database':'detabase_property'}
# config={'user': 'root', 'password': 'ma8h2dii', 'host': 'localhost','database':'detabase_mafia'} 
config={'user': 'root', 'password': 'ag9SEelFzUz2MjSN5nsu', 'host': 'localhost','database':'detabase_mafia'} 

