import random
d = {'s':[1,2,3], 'sx':[4,5,6]}
random_roles = random.sample(list(d), 0)
print(random_roles)